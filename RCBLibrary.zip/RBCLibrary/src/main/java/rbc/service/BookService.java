package rbc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityNotFoundException;
import rbc.entity.Book;
import rbc.exception.BookNotFoundException;
import rbc.repository.BookRepository;

@Service
public class BookService {
	@Autowired
	private BookRepository bookRepository;
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	public Book getBookById(Long id) {
		return bookRepository.findById(id)
				.orElseThrow(() -> new BookNotFoundException("NO BOOK PRESENT WITH ID : "+ id));
	}

	public Book createBook(Book book) {
		return bookRepository.save(book);
	}

	public Book updateBook(Long id, Book book) {
		Book existingBook = bookRepository.findById(id).orElse(null);
		if (existingBook != null) {
			existingBook.setTitle(book.getTitle());
			existingBook.setAuthor(book.getAuthor());
			existingBook.setPrice(book.getPrice());
			return bookRepository.save(existingBook);
		} else {
			return null;
		}
	}

	public void deleteBook(Long id) {
		Optional<Book> book = Optional.ofNullable(getBookById(id));
		if (!book.isEmpty())
			bookRepository.deleteById(id);
		else
			throw (new BookNotFoundException("NO BOOK PRESENT WITH ID :"+ id));
	}
}
