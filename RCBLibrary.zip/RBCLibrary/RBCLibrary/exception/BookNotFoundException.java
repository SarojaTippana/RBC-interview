package rcb.exception;

public class BookNotFoundException extends RuntimeException  {

	private static final long serialVersionUID = 1L;
		private String message;

	    public BookNotFoundException() {}

	    public BookNotFoundException(String msg) {
	        super(msg);
	        this.message = msg;
	    }
	}
