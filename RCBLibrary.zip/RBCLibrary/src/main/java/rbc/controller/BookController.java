package rbc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import rbc.entity.Book;
import rbc.service.BookService;

@RestController
@RequestMapping("/book")
public class BookController {

	/*
	 * POST /books: Add a new book. Each book should have id, title, author, and
	 * price. Validate that the price is non-negative.
	 * 
	 * GET /books: Retrieve a list of all books.
	 * 
	 * GET /books/{id}: Retrieve details of a specific book by id. Return a 404 if
	 * the book is not found.
	 * 
	 * PUT /books/{id}: Update an existing book's details. Validate that the price
	 * is non-negative. Return a 404 if the book is not found.
	 * 
	 * DELETE /books/{id}: Delete a book by id. Return a 404 if the book is not
	 * found.
	 */

	@Autowired
	private BookService bookService;

	@GetMapping("/healthCheck")
	public String health() {
		return "Hello User!!! the service is up and running!!!!!";
	}

	@GetMapping("/getAllBooks")
	public List<Book> getAllBooks() {
		return bookService.getAllBooks();
	}

	@GetMapping("/{id}")
	public Book getBookById(@PathVariable Long id) {
		return bookService.getBookById(id);
	}

	@PostMapping("/createBook")
	public Book createBook(@RequestBody @Valid Book book) {
		return bookService.createBook(book);
	}

	@PutMapping("/updateBook/{id}")
	public Book updateBook(@PathVariable Long id, @RequestBody @Valid Book book) {
		return bookService.updateBook(id, book);
	}

	@DeleteMapping("/deleteBook/{id}")
	public void deleteBook(@PathVariable Long id) {
		bookService.deleteBook(id);
	}

}
