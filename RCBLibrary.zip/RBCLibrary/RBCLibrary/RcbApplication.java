package rcb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RcbApplication {

	public static void main(String[] args) {
		SpringApplication.run(RcbApplication.class, args);
	}

}
