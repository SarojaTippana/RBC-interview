package com.example.rcb;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import rbc.controller.BookController;
import rbc.entity.Book;
import rbc.service.BookService;

@ExtendWith(MockitoExtension.class)
class BookControllerTest {

	@Mock
	private BookService bookService;

	@InjectMocks
	private BookController bookController;

	private Book book1;
	private Book book2;

	@BeforeEach
	void setUp() {
		book1 = new Book(1L, "Book One", "Author One", 20.0);
		book2 = new Book(2L, "Book Two", "Author Two", 25.0);
	}

	@Test
	void testGetAllBooks() {
		when(bookService.getAllBooks()).thenReturn(Arrays.asList(book1, book2));
		List<Book> books = bookController.getAllBooks();
		assertEquals(2, books.size());
		verify(bookService, times(1)).getAllBooks();
	}

	@Test
	void testGetBookById() {
		when(bookService.getBookById(1L)).thenReturn(book1);
		Book book = bookController.getBookById(1L);
		assertNotNull(book);
		assertEquals("Book One", book.getTitle());
		verify(bookService, times(1)).getBookById(1L);
	}

	@Test
	void testCreateBook() {
		when(bookService.createBook(any(Book.class))).thenReturn(book1);
		Book createdBook = bookController.createBook(book1);
		assertNotNull(createdBook);
		assertEquals("Book One", createdBook.getTitle());
		verify(bookService, times(1)).createBook(book1);
	}

	@Test
	void testUpdateBook() {
		when(bookService.updateBook(eq(1L), any(Book.class))).thenReturn(book1);
		Book updatedBook = bookController.updateBook(1L, book1);
		assertNotNull(updatedBook);
		assertEquals("Book One", updatedBook.getTitle());
		verify(bookService, times(1)).updateBook(1L, book1);
	}

	@Test
	void testDeleteBook() {
		doNothing().when(bookService).deleteBook(1L);
		bookController.deleteBook(1L);
		verify(bookService, times(1)).deleteBook(1L);
	}
}
